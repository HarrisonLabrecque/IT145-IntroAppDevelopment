//Created by Harrison LaBrecque
public class Monkey extends RescueAnimal {
	
	//Creating a list for the accepted species.
	public static String[] AllowedSpecies= {"Capuchin","Guenon","Macaque","Marmoset","Squirrel monkey","Tamarin"};
	
	//Monkey specific attributes
	private String tailLength;
	private String height;
	private String bodyLength;
	private String species;
	
	//Constructor method for the Monkey Class.
	public Monkey(String name,String species,String gender,String age,String weight,String acquisitionDate,
			String acquisitionCountry,String trainingStatus,boolean reserved,String serviceCountry,
			String tailLength,String height,String bodyLength) {
		//This line calls the constructor of the superclass (RescueAnimal) with the provided parameters to initialize inherited attributes.
		super(name,gender,age,weight,acquisitionDate,acquisitionCountry,trainingStatus,reserved,serviceCountry);
		//These lines assign the values of the parameters specific to the Monkey class (tailLength, height, bodyLength, species) to the corresponding instance variables of the Monkey object being created.
		this.tailLength = tailLength;
        this.height = height;
        this.bodyLength = bodyLength;
        this.species = species;
	}
	

	
	
	//This is a getter method for the tailLength instance variable. It returns the value of the tailLength.
    public String getTailLength() {
        return tailLength;
    }
    //This is a setter method for the tailLength instance variable. It sets the value of the tailLength to the value passed in as a parameter.
    public void setTailLength(String tailLength) {
        this.tailLength = tailLength;
    }
    //This is a getter method for the height instance variable. It returns the value of the height.
    public String getHeight() {
        return height;
    }
    // This is a setter method for the height instance variable. It sets the value of the height to the value passed in as a parameter.
    public void setHeight(String height) {
        this.height = height;
    }
    //This is a getter method for the bodyLength instance variable. It returns the value of the bodyLength.
    public String getBodyLength() {
        return bodyLength;
    }
    //This is a setter method for the bodyLength instance variable. It sets the value of the bodyLength to the value passed in as a parameter.
    public void setBodyLength(String bodyLength) {
        this.bodyLength = bodyLength;
    }
    // This is a getter method for the species instance variable. It returns the value of the species.
    public String getSpecies() {
        return species;
    }
    //This is a setter method for the species instance variable. It sets the value of the species to the value passed in as a parameter.
    public void setSpecies(String species) {
        this.species = species;
    }
}
	
