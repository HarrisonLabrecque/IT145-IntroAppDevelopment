import java.util.ArrayList;
import java.util.Scanner;

public class Driver {
	// Declaring private ArrayLists to hold Dog and Monkey objects
    private static ArrayList<Dog> dogList = new ArrayList<Dog>();
    private static ArrayList<Monkey> monkeyList = new ArrayList<Monkey>();

    public static void main(String[] args) {
    	//Initializing the lists with some sample data
        initializeDogList();
        initializeMonkeyList();
        
    

        // Add a loop that displays the menu, accepts the users input
        // and takes the appropriate action.
	// For the project submission you must also include input validation
        // and appropriate feedback to the user.
        // Hint: create a Scanner and pass it to the necessary
        // methods 
	// Hint: Menu options 4, 5, and 6 should all connect to the printAnimals() method.
        
    //  Creating a Scanner object to read input from the console
        Scanner option = new Scanner(System.in);
      //Declaring a String variable to hold the menu option
        String menuOption = "";
        
      //Starting a loop to display the menu and handle user input until 'q' is entered.
        while (!menuOption.equals("q")) {
        	// Displaying the menu options
        	displayMenu();
        	
        	//Reading the user's menu selection.
        	menuOption = option.nextLine();
        	
        //Using a switch statement to execute the appropriate action based on the user's input
        	switch(menuOption) {
        	case "1":
        		intakeNewDog(option);
        		break;
        	case "2":
        		intakeNewMonkey(option);
        		break;
        	case "3":
        		reserveAnimal(option);
        		break;
        	case "4":
        		printAnimals("dog");
        		break;
        	case "5":
        		printAnimals("monkey");
        		break;
        	case "6":
        		printAnimals("available");
        		break;
        	case "q":
        		break;
        	default:
        		System.out.println("Invalid menu option. Please try again.");
        		break;
        		
        	}
        	
        }
     // Closing the Scanner object to prevent resource leaks
        option.close();
        

    }

    // This method prints the menu options
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }


    // Adds dogs to a list for testing
    public static void initializeDogList() {
        Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "intake", false, "United States");
        Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", false, "United States");
        Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", true, "Canada");
        
    

        dogList.add(dog1);
        dogList.add(dog2);
        dogList.add(dog3);
    }


    // Adds monkeys to a list for testing
    //Optional for testing
    public static void initializeMonkeyList() {
    	// Creating Monkey objects and adding them to the monkeyList
    	Monkey monkey1 = new Monkey("Lola", "Tamarin", "female", "3", "4.2", "06-07-2018", "United States", "intake", false, "United States","15.2","11","12.4");
    	Monkey monkey2 = new Monkey("Steve", "Capuchin", "male", "4", "6", "11-10-2022", "United States", "Phase I", false, "United States","14.8","15.1","17.0");
    	Monkey monkey3 = new Monkey("Jacque", "Guenon", "male", "5", "7.3", "08-25-2016", "Canada", "in service", true, "Canada","13.7","11.6","14.9");
    	
    	monkeyList.add(monkey1);
    	monkeyList.add(monkey2);
    	monkeyList.add(monkey3);

    }


    // Complete the intakeNewDog method
    // The input validation to check that the dog is not already in the list
    // is done for you
    //// Method to intake a new dog
    public static void intakeNewDog(Scanner scanner) {
        System.out.println("What is the dog's name?");
        String name = scanner.nextLine();
        if (name == null || name.trim().isEmpty()) {
        	System.out.println("Invalid name. Please enter a non-empty name.");
        	return; // Return to the menu
        }
        for(Dog dog: dogList) {
            if(dog.getName() != null && dog.getName().equalsIgnoreCase(name)) {
                System.out.println("\n\nThis dog is already in our system\n\n");
                return; //returns to menu
            }
        }

        // Add the code to instantiate a new dog and add it to the appropriate list
        //Prompting for and storing information about the new dog
        System.out.println("What is the dog's breed?");
        String breed = scanner.nextLine();
        System.out.println("What is the dog's gender?");
        String gender = scanner.nextLine();
        System.out.println("What is the dog's age?");
        String age = scanner.nextLine();
        System.out.println("What is the dog's weight?");
        String weight = scanner.nextLine();
        System.out.println("What is the dog's acquisition date?");
        String acquisitionDate = scanner.nextLine();
        System.out.println("What is the dog's acquisition country?");
        String acquisitionCountry = scanner.nextLine();
        System.out.println("What is the dog's training status?");
        String trainingStatus = scanner.nextLine();
        System.out.println("Is the dog reserved? (true/false)");
        boolean reserved = Boolean.parseBoolean(scanner.nextLine());
        System.out.println("What is the dog's service country?");
        String serviceCountry = scanner.nextLine();
        
     //Creating a new Dog object with the entered information and adding it to the dogList
        Dog newDog = new Dog(name, breed, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved, serviceCountry);
        dogList.add(newDog);
    }


        // Complete intakeNewMonkey
	//Instantiate and add the new monkey to the appropriate list
        // For the project submission you must also  validate the input
	// to make sure the monkey doesn't already exist and the species type is allowed
    //Method to intake a new monkey
        public static void intakeNewMonkey(Scanner scanner) {
        	//Prompting the user to enter information about the new monkey
        	System.out.println("What is the monkey's name?");
        	String name = scanner.nextLine();
        	if (name == null || name.trim().isEmpty()) {
        		 System.out.println("Invalid name. Please enter a non-empty name.");
        		 return; // Return to the menu
        	}
        	//Checking if the monkey already exists in the list
        	for (Monkey monkey : monkeyList) {
        		if (monkey.getName() != null && monkey.getName().equalsIgnoreCase(name)) {
        			System.out.println("\n\nThis monkey is already in our system\n\n");
        			return; //return to menu
        		}
        	}
        	//Prompting  the user to enter in the species of the monkey and check it against the list.
        	boolean invalid_species = true;
        	String species;
        	
        	do {
        		 System.out.println("What is the monkey's species?");
        		 species = scanner.nextLine();
        		 
        		 for(String valid_species: Monkey.AllowedSpecies)
        			 if(species.equalsIgnoreCase(valid_species))
        				 invalid_species = false;
        		 
        		 if(invalid_species)
        			 System.out.println("Invalid species.");
        	}while(invalid_species);
        	
        	 System.out.println("What is the monkey's gender?");
        	 String gender = scanner.nextLine();
        	 System.out.println("What is the monkey's age?");
        	 String age = scanner.nextLine();
        	 System.out.println("What is the monkey's weight?");
        	 String weight = scanner.nextLine();
        	 System.out.println("What is the monkey's acquisition date?");
        	 String acquisitionDate = scanner.nextLine();
        	 System.out.println("What is the monkey's acquisition country?");
        	 String acquisitionCountry = scanner.nextLine();
        	 System.out.println("What is the monkey's training status?");
        	 String trainingStatus = scanner.nextLine();
        	 System.out.println("Is the monkey reserved? (true/false)");
        	 boolean reserved = Boolean.parseBoolean(scanner.nextLine());
        	 System.out.println("What is the monkey's service country?");
        	 String serviceCountry = scanner.nextLine();
        	 System.out.println("What is the monkey's tail length?");
        	 String tailLength = scanner.nextLine();
        	 System.out.println("What is the monkey's height?");
        	 String height = scanner.nextLine();
        	 System.out.println("What is the monkey's body length?");
        	 String bodyLength = scanner.nextLine();
        	 
        	//Creating a new Monkey object with the entered information and adding it to the monkeyList.
        	 Monkey newMonkey = new Monkey(name,species, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved, serviceCountry, tailLength, height, bodyLength);
        	 monkeyList.add(newMonkey);
        	 
        	
        	
        	
            
        }

        // Complete reserveAnimal
        // You will need to find the animal by animal type and in service country
        public static void reserveAnimal(Scanner scanner) {
        	//Prompting the user to enter the animal type and service country
        	System.out.println("Enter the animal type (dog/monkey): ");
        	String animalType = scanner.nextLine().toLowerCase();
        	System.out.println("Enter the service country: ");
        	String serviceCountry = scanner.nextLine();
        	
        	//checks if the input animal type is a dog.
        	if (animalType.equalsIgnoreCase("dog")) {
        		// If the animal type is a dog, it prompts the user to enter the name of the dog.
        		System.out.println("Enter the name of the dog: ");
        		 String name = scanner.nextLine();
        		//It then iterates through a list of dogs using a for-each loop to find a match based on the provided name, service location, and reservation status.
        		for (Dog dog : dogList) {
        			if (dog.getName().equalsIgnoreCase(name) && dog.getInServiceLocation().equalsIgnoreCase(serviceCountry) && !dog.getReserved()) {
        				// If a matching dog is found with the specified name, service location, and is not already reserved, it sets the reservation status to true.
        				dog.setReserved(true);
        				// It prints a message confirming that the dog has been reserved.
        				System.out.println("Dog has been reserved");
        				return; 
        			}
        		}
        	}
        	//Checks if the input animal type is a monkey.
        	if (animalType.equalsIgnoreCase("monkey")) {
        		//If the animal type is a monkey, it prompts the user to enter the name of the monkey.
        		System.out.println("Enter the name of the monkey: ");
        		String name = scanner.nextLine();
        		//It then iterates through a list of monkeys to find a match based on the provided name, service location, and reservation status.
        		for (Monkey monkey : monkeyList) {
        			if(monkey.getName().equalsIgnoreCase(name) && monkey.getInServiceLocation().equalsIgnoreCase(serviceCountry) && !monkey.getReserved()) {
        				//. If a matching monkey is found with the specified name, service location, and is not already reserved, it sets the reservation status to true.
        				monkey.setReserved(true);
        				// It prints a message confirming that the monkey has been reserved.
        				System.out.println("Monkey has been reserved");
        				
        				return;
        			}
        		}
        	}
        	
        	else {
        		System.out.println("Invalid animal type.");
        	}
        	
       
        	
        	     

        }

        // Complete printAnimals
        // Include the animal name, status, acquisition country and if the animal is reserved.
	// Remember that this method connects to three different menu items.
        // The printAnimals() method has three different outputs
        // based on the listType parameter
        // dog - prints the list of dogs
        // monkey - prints the list of monkeys
        // available - prints a combined list of all animals that are
        // fully trained ("in service") but not reserved 
	// Remember that you only have to fully implement ONE of these lists. 
	// The other lists can have a print statement saying "This option needs to be implemented".
	// To score "exemplary" you must correctly implement the "available" list.
        public static void printAnimals(String output) {
        	// prints a header for the output table with columns for Name, Status, Acquisition Country, and Reserved status.
        	System.out.println("Name\tStatus\tAcq. Country\tReserved");
        	// It then uses a switch statement based on the value of the 'output' variable.
        	switch(output) {
        	//If the 'output' is "dog", it iterates through the list of dogs and retrieves their name, training status, acquisition country, and reservation status.
        	case "dog":
        		for (Dog dog : dogList) {
        			String name = dog.getName();
        			String status = dog.getTrainingStatus();
        			String acquisitionCountry = dog.getAcquisitionLocation();
        			String reserved = String.valueOf(dog.getReserved()); // Convert boolean to String
        			// prints the dog's information in a tabular format.
        			System.out.println(name + "\t" + status + "\t" + acquisitionCountry + "\t" + reserved);

        			
        			 
        		}
        		break;
        	//If the 'output' is "monkey", it iterates through the list of monkeys and retrieves their information.
        	case "monkey":
        		for (Monkey monkey : monkeyList) {
        			String name = monkey.getName();
        			String status = monkey.getTrainingStatus();
        			String acquisitionCountry = monkey.getAcquisitionLocation();
        			String reserved = String.valueOf(monkey.getReserved()); // Convert boolean to String
        			// prints the monkey's information in a tabular format.
        			System.out.println(name + "\t" + status + "\t" + acquisitionCountry + "\t" + reserved);
        		}
        		
        		break;
        		// If the 'output' is "available", it iterates through both dog and monkey lists to find animals that are fully trained but not reserved.
        	case "available":
        		for (Dog dog : dogList) {
        			if (dog.getTrainingStatus().equalsIgnoreCase("in service") && !dog.getReserved()) {
        				 String name = dog.getName();
        				 String status = dog.getTrainingStatus();
        				 String acquisitionCountry = dog.getAcquisitionLocation();
        				 String reserved = String.valueOf(dog.getReserved()); // Convert boolean to String
        				// prints the dog's information in a tabular format.
        				 System.out.println(name + "\t" + status + "\t" + acquisitionCountry + "\t" + reserved);
        			}
        		}
        		for (Monkey monkey : monkeyList) {
        			if (monkey.getTrainingStatus().equalsIgnoreCase("in service") && !monkey.getReserved()) {
        				String name = monkey.getName();
        				String status = monkey.getTrainingStatus();
        				String acquisitionCountry = monkey.getAcquisitionLocation();
        				String reserved = String.valueOf(monkey.getReserved()); // Convert boolean to String
        				// prints the monkey's information in a tabular format.
        				System.out.println(name + "\t" + status + "\t" + acquisitionCountry + "\t" + reserved);
        			}
        		}
        		break;
        	
        	default:
        		System.out.println("Invalid output option.");
        		break;
        	}
        	
        	
           
        }
        
        
}

